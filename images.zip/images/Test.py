x=10
for i in range(x):
    print("Hi there")
